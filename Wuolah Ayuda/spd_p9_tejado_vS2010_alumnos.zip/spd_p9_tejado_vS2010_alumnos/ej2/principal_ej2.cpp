//----------------------------------------------------
//////////////////////////////////////////////////////////////////////////////////////////////////////////////
//  Dpto ATC. www.atc.us.es 
//  SPD subject 3� GTI
//  - Understanding basic concepts for OpenMP
//-----------------------------------------------------

using namespace std;

#include <iostream>
#include <iomanip>
#include <stdint.h>
#include <omp.h>

void part_a_b_c (int n);

int main()
{
	//-----------------------------------
	part_a_b_c(8);
	//-----------------------------------
}

void part_a_b_c (int n)
{
	//#pragma omp parallel
	{
		int this_thread = omp_get_thread_num();
		for (int i=0;i<n;i++)
		{
			cout << "Iteration " << i << " is handled by thread " << this_thread << endl;
		}
	}
}
